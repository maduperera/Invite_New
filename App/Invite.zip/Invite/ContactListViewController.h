//
//  ContactListViewController.h
//  Invite
//
//  Created by Dhammini Fernando on 4/2/14.
//  Copyright (c) 2014 Dhammini Fernando. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactListViewController : UIViewController

@end
