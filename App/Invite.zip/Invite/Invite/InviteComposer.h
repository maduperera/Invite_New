//
//  InviteComposer.h
//  Invite
//
//  Created by Madusha Perera on 3/21/14.
//  Copyright (c) 2014 Dhammini Fernando. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InviteLoginViewController.h"
#import "InviteSignupViewController.h"

@interface InviteComposer : UIViewController//<PFLogInViewControllerDelegate, PFSignUpViewControllerDelegate>

@end
