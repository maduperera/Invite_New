//
//  OutBoxCustomCell.m
//  Invite
//
//  Created by Madusha Perera on 3/30/14.
//  Copyright (c) 2014 Dhammini Fernando. All rights reserved.
//

#import "OutBoxCustomCell.h"

@implementation OutBoxCustomCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
