//
//  TemplateCell.m
//  Invite
//
//  Created by Madusha Perera on 3/27/14.
//  Copyright (c) 2014 Dhammini Fernando. All rights reserved.
//

#import "TemplateCell.h"

@implementation TemplateCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

@end
