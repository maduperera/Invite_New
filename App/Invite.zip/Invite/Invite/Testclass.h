//
//  Testclass.h
//  Invite
//
//  Created by Dhammini on 4/15/14.
//  Copyright (c) 2014 Dhammini Fernando. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "BlurViewController.h"


@interface Testclass : BlurViewController

@end
