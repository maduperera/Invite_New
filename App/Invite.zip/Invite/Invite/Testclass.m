//
//  Testclass.m
//  Invite
//
//  Created by Dhammini on 4/15/14.
//  Copyright (c) 2014 Dhammini Fernando. All rights reserved.
//

#import "Testclass.h"

@implementation Testclass

@end
