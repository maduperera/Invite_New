//
//  AppDelegate.h
//  Geolocations
//
//  Created by Héctor Ramos on 7/31/12.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
